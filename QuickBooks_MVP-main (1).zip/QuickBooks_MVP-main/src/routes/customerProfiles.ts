import { Router, Request, Response } from "express";
import { body, param, query, validationResult } from "express-validator";
import {
  CustomerProfileService,
  CreateCustomerProfileData,
  UpdateCustomerProfileData,
} from "../services/CustomerProfileService";
import { logger } from "../utils/logger";

const router = Router();

// Lazy initialization of CustomerProfileService to avoid database connection issues
let customerProfileService: CustomerProfileService | null = null;

const getCustomerProfileService = (): CustomerProfileService => {
  if (!customerProfileService) {
    customerProfileService = new CustomerProfileService();
  }
  return customerProfileService;
};

/**
 * GET /customer-profiles - Get all customer profiles with pagination and filtering
 */
router.get(
  "/",
  [
    query("page").optional().isInt({ min: 1 }).toInt(),
    query("limit").optional().isInt({ min: 1, max: 100 }).toInt(),
    query("search").optional().isString().trim(),
    query("isActive").optional().isBoolean().toBoolean(),
    query("hasQboCustomerId").optional().isBoolean().toBoolean(),
    query("hasGenesysQueues").optional().isBoolean().toBoolean(),
    query("queueName").optional().isString().trim(),
  ],
  async (req: Request, res: Response) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          success: false,
          errors: errors.array(),
        });
      }

      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 20;
      const filters = {
        search: req.query.search as string,
        isActive: req.query.isActive as boolean | undefined,
        hasQboCustomerId: req.query.hasQboCustomerId as boolean | undefined,
        hasGenesysQueues: req.query.hasGenesysQueues as boolean | undefined,
        queueName: req.query.queueName as string,
      };

      const result = await getCustomerProfileService().getCustomerProfiles(
        page,
        limit,
        filters
      );

      res.json({
        success: true,
        data: result.customerProfiles,
        pagination: result.pagination,
      });
    } catch (error) {
      logger.error("Failed to get customer profiles", { error });
      res.status(500).json({
        success: false,
        error:
          error instanceof Error
            ? error.message
            : "Failed to get customer profiles",
      });
    }
  }
);

/**
 * GET /customer-profiles/:id - Get specific customer profile
 */
router.get(
  "/:id",
  [param("id").isUUID()],
  async (req: Request, res: Response) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          success: false,
          errors: errors.array(),
        });
      }

      const { id } = req.params;
      const profile = await getCustomerProfileService().getCustomerProfileById(
        id
      );

      res.json({
        success: true,
        data: profile,
      });
    } catch (error) {
      logger.error("Failed to get customer profile", {
        error,
        id: req.params.id,
      });

      if (
        error instanceof Error &&
        error.message === "Customer profile not found"
      ) {
        return res.status(404).json({
          success: false,
          error: "Customer profile not found",
        });
      }

      res.status(500).json({
        success: false,
        error:
          error instanceof Error
            ? error.message
            : "Failed to get customer profile",
      });
    }
  }
);

/**
 * GET /customer-profiles/:id/stats - Get customer profile statistics
 */
router.get(
  "/:id/stats",
  [param("id").isUUID()],
  async (req: Request, res: Response) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          success: false,
          errors: errors.array(),
        });
      }

      const { id } = req.params;
      const stats = await getCustomerProfileService().getCustomerProfileStats(
        id
      );

      res.json({
        success: true,
        data: stats,
      });
    } catch (error) {
      logger.error("Failed to get customer profile stats", {
        error,
        id: req.params.id,
      });

      if (
        error instanceof Error &&
        error.message === "Customer profile not found"
      ) {
        return res.status(404).json({
          success: false,
          error: "Customer profile not found",
        });
      }

      res.status(500).json({
        success: false,
        error:
          error instanceof Error
            ? error.message
            : "Failed to get customer profile statistics",
      });
    }
  }
);

/**
 * POST /customer-profiles - Create new customer profile
 */
router.post(
  "/",
  [
    body("qboDisplayName")
      .isString()
      .trim()
      .notEmpty()
      .withMessage("QBO Display Name is required"),
    body("genesysQueueNames")
      .custom((value) => {
        // Handle both string and array inputs
        if (typeof value === "string") {
          // Convert single string to array
          return [value.trim()];
        }
        if (Array.isArray(value)) {
          // Validate array
          if (value.length === 0) {
            throw new Error("At least one Genesys queue name is required");
          }
          return value.map((item) =>
            typeof item === "string" ? item.trim() : item
          );
        }
        throw new Error("Genesys queue names must be a string or array");
      })
      .withMessage("Genesys queue names must be a string or array"),
    body("qboCustomerId").optional().isString().trim(),
    body("ratePerMinute")
      .optional()
      .isFloat({ min: 0 })
      .withMessage("Rate must be a positive number"),
    body("taxCode").optional().isString().trim(),
    body("notes").optional().isString().trim(),
    body("isActive").optional().isBoolean(),

    // QBO Customer Fields
    body("qboCompanyName").optional().isString().trim(),
    body("qboGivenName").optional().isString().trim(),
    body("qboFamilyName").optional().isString().trim(),
    body("qboMiddleName").optional().isString().trim(),
    body("qboTitle").optional().isString().trim(),
    body("qboSuffix").optional().isString().trim(),

    // QBO Contact Fields
    body("qboPrimaryEmailAddr")
      .optional()
      .if(body("qboPrimaryEmailAddr").exists())
      .isEmail()
      .withMessage("Invalid email format"),
    body("qboPrimaryPhone").optional().isString().trim(),

    // QBO Address Fields
    body("qboLine1").optional().isString().trim(),
    body("qboCity").optional().isString().trim(),
    body("qboCountrySubDivisionCode").optional().isString().trim(),
    body("qboPostalCode").optional().isString().trim(),
    body("qboCountry").optional().isString().trim(),
  ],
  async (req: Request, res: Response) => {
    console.log("req.body", req.body);
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          success: false,
          errors: errors.array(),
        });
      }

      const profileData: CreateCustomerProfileData = req.body;

      // Convert empty qboCustomerId to undefined to avoid database constraint issues
      if (profileData.qboCustomerId === "") {
        profileData.qboCustomerId = undefined;
      }

      const profile = await getCustomerProfileService().createCustomerProfile(
        profileData
      );

      res.status(201).json({
        success: true,
        message: "Customer profile created successfully",
        data: profile,
      });
    } catch (error) {
      logger.error("Failed to create customer profile", {
        error,
        profileData: req.body,
      });

      if (error instanceof Error && error.message.includes("already exists")) {
        return res.status(409).json({
          success: false,
          error: error.message,
        });
      }

      res.status(500).json({
        success: false,
        error:
          error instanceof Error
            ? error.message
            : "Failed to create customer profile",
      });
    }
  }
);

/**
 * PUT /customer-profiles/:id - Update customer profile
 */
router.put(
  "/:id",
  [
    param("id").isUUID(),
    body("qboDisplayName")
      .optional()
      .isString()
      .trim()
      .notEmpty()
      .withMessage("QBO Display Name cannot be empty"),
    body("genesysQueueNames")
      .optional()
      .custom((value) => {
        // Handle both string and array inputs
        if (typeof value === "string") {
          // Convert single string to array
          return [value.trim()];
        }
        if (Array.isArray(value)) {
          // Validate array
          if (value.length === 0) {
            throw new Error("At least one Genesys queue name is required");
          }
          return value.map((item) =>
            typeof item === "string" ? item.trim() : item
          );
        }
        throw new Error("Genesys queue names must be a string or array");
      })
      .withMessage("Genesys queue names must be a string or array"),
    body("qboCustomerId").optional().isString().trim(),
    body("ratePerMinute")
      .optional()
      .isFloat({ min: 0 })
      .withMessage("Rate must be a positive number"),
    body("taxCode").optional().isString().trim(),
    body("notes").optional().isString().trim(),
    body("isActive").optional().isBoolean(),

    // QBO Customer Fields
    body("qboCompanyName").optional().isString().trim(),
    body("qboGivenName").optional().isString().trim(),
    body("qboFamilyName").optional().isString().trim(),
    body("qboMiddleName").optional().isString().trim(),
    body("qboTitle").optional().isString().trim(),
    body("qboSuffix").optional().isString().trim(),

    // QBO Contact Fields
    body("qboPrimaryEmailAddr")
      .optional()
      .if(body("qboPrimaryEmailAddr").exists())
      .isEmail()
      .withMessage("Invalid email format"),
    body("qboPrimaryPhone").optional().isString().trim(),

    // QBO Address Fields
    body("qboLine1").optional().isString().trim(),
    body("qboCity").optional().isString().trim(),
    body("qboCountrySubDivisionCode").optional().isString().trim(),
    body("qboPostalCode").optional().isString().trim(),
    body("qboCountry").optional().isString().trim(),
  ],
  async (req: Request, res: Response) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          success: false,
          errors: errors.array(),
        });
      }

      const { id } = req.params;
      const updateData: UpdateCustomerProfileData = req.body;

      // Convert empty qboCustomerId to undefined to avoid database constraint issues
      if (updateData.qboCustomerId === "") {
        updateData.qboCustomerId = undefined;
      }

      const profile = await getCustomerProfileService().updateCustomerProfile(
        id,
        updateData
      );

      res.json({
        success: true,
        message: "Customer profile updated successfully",
        data: profile,
      });
    } catch (error) {
      logger.error("Failed to update customer profile", {
        error,
        id: req.params.id,
        updateData: req.body,
      });

      if (
        error instanceof Error &&
        error.message === "Customer profile not found"
      ) {
        return res.status(404).json({
          success: false,
          error: "Customer profile not found",
        });
      }

      if (error instanceof Error && error.message.includes("already exists")) {
        return res.status(409).json({
          success: false,
          error: error.message,
        });
      }

      res.status(500).json({
        success: false,
        error:
          error instanceof Error
            ? error.message
            : "Failed to update customer profile",
      });
    }
  }
);

/**
 * DELETE /customer-profiles/:id - Delete customer profile
 */
router.delete(
  "/:id",
  [param("id").isUUID()],
  async (req: Request, res: Response) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          success: false,
          errors: errors.array(),
        });
      }

      const { id } = req.params;
      await getCustomerProfileService().deleteCustomerProfile(id);

      res.json({
        success: true,
        message: "Customer profile deleted successfully",
        data: { id },
      });
    } catch (error) {
      logger.error("Failed to delete customer profile", {
        error,
        id: req.params.id,
      });

      if (
        error instanceof Error &&
        error.message === "Customer profile not found"
      ) {
        return res.status(404).json({
          success: false,
          error: "Customer profile not found",
        });
      }

      if (
        error instanceof Error &&
        error.message.includes("existing phone usage records")
      ) {
        return res.status(400).json({
          success: false,
          error: error.message,
        });
      }

      res.status(500).json({
        success: false,
        error:
          error instanceof Error
            ? error.message
            : "Failed to delete customer profile",
      });
    }
  }
);

/**
 * POST /customer-profiles/bulk-status - Bulk update customer profile status
 */
router.post(
  "/bulk-status",
  [
    body("profileIds")
      .isArray({ min: 1 })
      .withMessage("At least one profile ID is required"),
    body("profileIds.*").isUUID().withMessage("Invalid profile ID format"),
    body("isActive").isBoolean().withMessage("isActive must be a boolean"),
  ],
  async (req: Request, res: Response) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          success: false,
          errors: errors.array(),
        });
      }

      const { profileIds, isActive } = req.body;
      await getCustomerProfileService().bulkUpdateStatus(profileIds, isActive);

      res.json({
        success: true,
        message: "Customer profile statuses updated successfully",
        data: { updatedCount: profileIds.length },
      });
    } catch (error) {
      logger.error("Failed to bulk update customer profile status", {
        error,
        profileIds: req.body.profileIds,
      });
      res.status(500).json({
        success: false,
        error:
          error instanceof Error
            ? error.message
            : "Failed to update customer profile statuses",
      });
    }
  }
);

/**
 * GET /customer-profiles/search/quick - Quick search customer profiles
 */
router.get(
  "/search/quick",
  [
    query("q")
      .isString()
      .trim()
      .notEmpty()
      .withMessage("Search query is required"),
    query("limit").optional().isInt({ min: 1, max: 50 }).toInt(),
  ],
  async (req: Request, res: Response) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          success: false,
          errors: errors.array(),
        });
      }

      const query = req.query.q as string;
      const limit = parseInt(req.query.limit as string) || 10;
      const profiles = await getCustomerProfileService().searchCustomerProfiles(
        query,
        limit
      );

      res.json({
        success: true,
        data: profiles,
      });
    } catch (error) {
      logger.error("Failed to search customer profiles", {
        error,
        query: req.query.q,
      });
      res.status(500).json({
        success: false,
        error:
          error instanceof Error
            ? error.message
            : "Failed to search customer profiles",
      });
    }
  }
);

/**
 * GET /customer-profiles/active - Get all active customer profiles
 */
router.get("/active", async (req: Request, res: Response) => {
  try {
    const profiles =
      await getCustomerProfileService().getActiveCustomerProfiles();

    res.json({
      success: true,
      data: profiles,
    });
  } catch (error) {
    logger.error("Failed to get active customer profiles", { error });
    res.status(500).json({
      success: false,
      error:
        error instanceof Error
          ? error.message
          : "Failed to get active customer profiles",
    });
  }
});

/**
 * GET /customer-profiles/queues/all - Get all queue names across all profiles
 */
router.get("/queues/all", async (req: Request, res: Response) => {
  try {
    const queueNames = await getCustomerProfileService().getAllQueueNames();

    res.json({
      success: true,
      data: queueNames,
    });
  } catch (error) {
    logger.error("Failed to get all queue names", { error });
    res.status(500).json({
      success: false,
      error:
        error instanceof Error
          ? error.message
          : "Failed to get all queue names",
    });
  }
});

/**
 * POST /customer-profiles/:id/sync-qbo - Sync QBO customer data to profile
 */
router.post(
  "/:id/sync-qbo",
  [
    param("id").isUUID(),
    body("qboData").isObject().withMessage("QBO data is required"),
  ],
  async (req: Request, res: Response) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          success: false,
          errors: errors.array(),
        });
      }

      const { id } = req.params;
      const { qboData } = req.body;
      const profile = await getCustomerProfileService().syncQBOData(
        id,
        qboData
      );

      res.json({
        success: true,
        message: "QBO data synced successfully",
        data: profile,
      });
    } catch (error) {
      logger.error("Failed to sync QBO data", { error, id: req.params.id });

      if (
        error instanceof Error &&
        error.message === "Customer profile not found"
      ) {
        return res.status(404).json({
          success: false,
          error: "Customer profile not found",
        });
      }

      res.status(500).json({
        success: false,
        error:
          error instanceof Error ? error.message : "Failed to sync QBO data",
      });
    }
  }
);

/**
 * POST /customer-profiles/:id/reschedule-billing - Manually reschedule billing job for a customer
 */
router.post("/:id/reschedule-billing", async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    // Get the customer profile
    const profile = await getCustomerProfileService().getCustomerProfileById(
      id
    );
    if (!profile) {
      return res.status(404).json({
        success: false,
        error: "Customer profile not found",
      });
    }

    // Check if profile is active
    if (!profile.isActive) {
      return res.status(400).json({
        success: false,
        error: "Cannot reschedule billing for inactive customer profile",
      });
    }

    // Reschedule billing job
    try {
      const { QueueBillingScheduler } = await import(
        "../jobs/billingScheduler"
      );
      const billingScheduler = new QueueBillingScheduler();

      billingScheduler.rescheduleBilling(profile);

      logger.info("Manually rescheduled billing job for customer", {
        customerId: profile.id,
        customerName: profile.qboDisplayName,
        billingConfig: profile.getBillingConfigSummary(),
      });

      res.json({
        success: true,
        message: "Billing job rescheduled successfully",
        data: {
          customerId: profile.id,
          customerName: profile.qboDisplayName,
          billingConfig: profile.getBillingConfigSummary(),
          nextRun: "Will be calculated on next scheduler check",
        },
      });
    } catch (rescheduleError) {
      logger.error("Failed to manually reschedule billing job", {
        error: rescheduleError,
        customerId: profile.id,
        customerName: profile.qboDisplayName,
      });

      res.status(500).json({
        success: false,
        error: "Failed to reschedule billing job",
        details:
          rescheduleError instanceof Error
            ? rescheduleError.message
            : "Unknown error",
      });
    }
  } catch (error) {
    logger.error("Failed to reschedule billing job", { error });
    res.status(500).json({
      success: false,
      error: "Failed to reschedule billing job",
    });
  }
});

/**
 * POST /customer-profiles/reschedule-all-billing - Reschedule all billing jobs for active customers
 */
router.post("/reschedule-all-billing", async (req: Request, res: Response) => {
  try {
    // Get all active customer profiles
    const activeProfiles =
      await getCustomerProfileService().getActiveCustomerProfiles();

    if (activeProfiles.length === 0) {
      return res.status(404).json({
        success: false,
        error: "No active customer profiles found",
      });
    }

    // Reschedule billing for all active profiles
    try {
      const { QueueBillingScheduler } = await import(
        "../jobs/billingScheduler"
      );
      const billingScheduler = new QueueBillingScheduler();

      let successCount = 0;
      let errorCount = 0;

      for (const profile of activeProfiles) {
        try {
          billingScheduler.rescheduleBilling(profile);
          successCount++;
        } catch (profileError) {
          errorCount++;
          logger.error("Failed to reschedule billing for profile", {
            error: profileError,
            customerId: profile.id,
            customerName: profile.qboDisplayName,
          });
        }
      }

      logger.info("Bulk rescheduled billing jobs", {
        totalProfiles: activeProfiles.length,
        successCount,
        errorCount,
      });

      res.json({
        success: true,
        message: "Billing jobs rescheduled successfully",
        data: {
          totalProfiles: activeProfiles.length,
          successCount,
          errorCount,
          profiles: activeProfiles.map((p) => ({
            id: p.id,
            name: p.qboDisplayName,
            billingConfig: p.getBillingConfigSummary(),
          })),
        },
      });
    } catch (rescheduleError) {
      logger.error("Failed to bulk reschedule billing jobs", {
        error: rescheduleError,
        totalProfiles: activeProfiles.length,
      });

      res.status(500).json({
        success: false,
        error: "Failed to reschedule billing jobs",
        details:
          rescheduleError instanceof Error
            ? rescheduleError.message
            : "Unknown error",
      });
    }
  } catch (error) {
    logger.error("Failed to get active customer profiles for rescheduling", {
      error,
    });
    res.status(500).json({
      success: false,
      error: "Failed to get customer profiles",
    });
  }
});

export { router as customerProfileRoutes };
