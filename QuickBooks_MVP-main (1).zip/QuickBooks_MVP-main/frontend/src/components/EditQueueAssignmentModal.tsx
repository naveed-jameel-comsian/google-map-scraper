import { useState, useEffect } from "react";
import { X } from "lucide-react";
import { toast } from "react-hot-toast";

interface Team {
  id: string;
  name: string;
  region: {
    id: string;
    name: string;
  };
}

interface QueueAssignment {
  id: string;
  queueId: string;
  queueName: string;
  teamId: string;
  assignedAt: string;
  assignedBy?: string;
  notes?: string;
  team: Team;
}

interface EditQueueAssignmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  assignment: QueueAssignment | null;
}

export function EditQueueAssignmentModal({ isOpen, onClose, onSuccess, assignment }: EditQueueAssignmentModalProps) {
  const [teams, setTeams] = useState<Team[]>([]);
  const [formData, setFormData] = useState({
    teamId: "",
    assignedBy: "",
    notes: ""
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [loadingTeams, setLoadingTeams] = useState(false);

  useEffect(() => {
    if (isOpen) {
      fetchTeams();
    }
  }, [isOpen]);

  useEffect(() => {
    if (assignment) {
      setFormData({
        teamId: assignment.teamId,
        assignedBy: assignment.assignedBy || "",
        notes: assignment.notes || ""
      });
    }
  }, [assignment]);

  const fetchTeams = async () => {
    try {
      setLoadingTeams(true);
      const response = await fetch("/api/v1/teams");
      if (response.ok) {
        const data = await response.json();
        setTeams(data.data);
      }
    } catch (error) {
      console.error("Error fetching teams:", error);
      toast.error("Failed to load teams");
    } finally {
      setLoadingTeams(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.teamId) {
      toast.error("Please select a team");
      return;
    }

    if (!assignment) {
      toast.error("No assignment selected");
      return;
    }

    try {
      setIsSubmitting(true);
      const response = await fetch(`/api/v1/queue-assignments/${assignment.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          teamId: formData.teamId,
          assignedBy: formData.assignedBy || undefined,
          notes: formData.notes || undefined
        }),
      });

      if (response.ok) {
        toast.success("Queue assignment updated successfully");
        onSuccess();
        onClose();
      } else {
        const errorData = await response.json();
        toast.error(errorData.error || "Failed to update queue assignment");
      }
    } catch (error) {
      console.error("Error updating queue assignment:", error);
      toast.error("Failed to update queue assignment");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleDelete = async () => {
    if (!assignment) return;

    if (!confirm(`Are you sure you want to unassign the queue "${assignment.queueName}"? This will make it unassigned again.`)) {
      return;
    }

    try {
      setIsSubmitting(true);
      const response = await fetch(`/api/v1/queue-assignments/${assignment.id}`, {
        method: "DELETE",
      });

      if (response.ok) {
        toast.success("Queue assignment deleted successfully");
        onSuccess();
        onClose();
      } else {
        const errorData = await response.json();
        toast.error(errorData.error || "Failed to delete queue assignment");
      }
    } catch (error) {
      console.error("Error deleting queue assignment:", error);
      toast.error("Failed to delete queue assignment");
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen || !assignment) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex min-h-screen items-center justify-center p-4">
        <div className="fixed inset-0 bg-gray-500 bg-opacity-75" onClick={onClose}></div>
        <div className="relative bg-white rounded-lg shadow-xl max-w-md w-full">
          <div className="flex items-center justify-between p-6 border-b">
            <h3 className="text-lg font-medium text-gray-900">Edit Queue Assignment</h3>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600"
            >
              <X className="h-6 w-6" />
            </button>
          </div>
          
          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            <div className="bg-gray-50 p-3 rounded-md">
              <p className="text-sm font-medium text-gray-700">Queue</p>
              <p className="text-sm text-gray-900">{assignment.queueName}</p>
              <p className="text-xs text-gray-500">ID: {assignment.queueId}</p>
            </div>

            <div>
              <label htmlFor="teamId" className="block text-sm font-medium text-gray-700">
                Team *
              </label>
              <select
                id="teamId"
                name="teamId"
                value={formData.teamId}
                onChange={handleChange}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                required
                disabled={loadingTeams}
              >
                <option value="">Select a team</option>
                {teams.map((team) => (
                  <option key={team.id} value={team.id}>
                    {team.name} ({team.region.name})
                  </option>
                ))}
              </select>
              {loadingTeams && (
                <p className="mt-1 text-sm text-gray-500">Loading teams...</p>
              )}
            </div>

            <div>
              <label htmlFor="assignedBy" className="block text-sm font-medium text-gray-700">
                Assigned By
              </label>
              <input
                type="text"
                id="assignedBy"
                name="assignedBy"
                value={formData.assignedBy}
                onChange={handleChange}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                placeholder="Your name (optional)"
              />
            </div>

            <div>
              <label htmlFor="notes" className="block text-sm font-medium text-gray-700">
                Notes
              </label>
              <textarea
                id="notes"
                name="notes"
                value={formData.notes}
                onChange={handleChange}
                rows={3}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                placeholder="Optional notes about this assignment"
              />
            </div>

            <div className="flex justify-between pt-4">
              <button
                type="button"
                onClick={handleDelete}
                disabled={isSubmitting}
                className="px-4 py-2 text-sm font-medium text-white bg-red-600 border border-transparent rounded-md hover:bg-red-700 disabled:opacity-50"
              >
                {isSubmitting ? "Unassigning..." : "Unassign Queue"}
              </button>
              <div className="flex space-x-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting || loadingTeams}
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md hover:bg-blue-700 disabled:opacity-50"
                >
                  {isSubmitting ? "Updating..." : "Update Assignment"}
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
